public class MapTest {
    public static void main(String[] args) {
        Map x = new Map();

        x.trackList();
    }
}